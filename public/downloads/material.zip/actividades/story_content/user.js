function ExecuteScript(strId)
{
  switch (strId)
  {
      case "68Uj2JkdKn5":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

