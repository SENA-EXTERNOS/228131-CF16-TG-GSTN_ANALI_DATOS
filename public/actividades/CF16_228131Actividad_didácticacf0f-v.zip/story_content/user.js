function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6MmlwVhbAD0":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

